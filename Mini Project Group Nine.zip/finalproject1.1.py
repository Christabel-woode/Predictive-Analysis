# Cell
import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score

# Load dataset
df = pd.read_csv("data.csv")

# Streamlit UI
st.title("Student Performance Analysis")
st.write("## Dataset Overview")
st.write(df.head())

# Summary statistics
st.write("## Summary Statistics")
st.write(df.describe())

# Correlation heatmap
st.write("## Correlation Matrix")
plt.figure(figsize=(8, 5))
sns.heatmap(df.corr(), annot=True, cmap="coolwarm", fmt=".2f")
st.pyplot(plt)

# Regression Model
st.write("## Predicting Student Grades")
X = df.drop(columns=["Grades"])
y = df["Grades"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# Display model performance
st.write(f"**Mean Absolute Error:** {mean_absolute_error(y_test, y_pred):.2f}")
st.write(f"**R-squared Score:** {r2_score(y_test, y_pred):.2f}")

# Feature importance visualization
st.write("## Feature Importance")
importance = pd.Series(model.coef_, index=X.columns)
plt.figure(figsize=(6, 4))
importance.sort_values().plot(kind='barh', color='skyblue')
st.pyplot(plt)

st.write("### Justification for Inclusion:")
st.write("- **Streamlit:** Provides an interactive web interface for analysis.")
st.write("- **Scikit-learn:** Enables machine learning predictions to understand the impact of different features on grades.")



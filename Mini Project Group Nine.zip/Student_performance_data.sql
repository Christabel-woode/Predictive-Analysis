-- SQL Schema for the dataset

-- Drop the table if it already exists to avoid duplication errors
IF OBJECT_ID('StudentPerformance', 'U') IS NOT NULL
    DROP TABLE StudentPerformance;

-- Create the table
CREATE TABLE StudentPerformance (
    SocioeconomicScore FLOAT,
    StudyHours FLOAT,
    SleepHours FLOAT,
    AttendancePercentage FLOAT,
    Grades FLOAT
);

-- Insert sample data (example with the first few rows)
INSERT INTO StudentPerformance (SocioeconomicScore, StudyHours, SleepHours, AttendancePercentage, Grades)
VALUES
    (0.95822, 3.4, 8.2, 53.0, 47.0),
    (0.85566, 3.2, 5.9, 55.0, 35.0),
    (0.68025, 3.2, 9.3, 41.0, 32.0),
    (0.25936, 3.2, 8.2, 47.0, 34.0),
    (0.60447, 3.8, 10.0, 75.0, 33.0);

-- Query examples

-- 1. Retrieve all records
SELECT * FROM StudentPerformance;

-- 2. Get students with Grades above 40
SELECT * FROM StudentPerformance
WHERE Grades > 40;

-- 3. Calculate the average Grades
SELECT AVG(Grades) AS AverageGrades FROM StudentPerformance;

-- 4. Find students with Attendance > 70% and Study Hours > 3.5
SELECT * FROM StudentPerformance
WHERE AttendancePercentage > 70 AND StudyHours > 3.5;

-- 5. Group students by Sleep Hours range and get average Grades
SELECT 
    CASE 
        WHEN SleepHours < 6 THEN 'Less than 6 hours'
        WHEN SleepHours BETWEEN 6 AND 8 THEN '6-8 hours'
        ELSE 'More than 8 hours'
    END AS SleepCategory,
    AVG(Grades) AS AverageGrades
FROM StudentPerformance
GROUP BY 
    CASE 
        WHEN SleepHours < 6 THEN 'Less than 6 hours'
        WHEN SleepHours BETWEEN 6 AND 8 THEN '6-8 hours'
        ELSE 'More than 8 hours'
    END;




